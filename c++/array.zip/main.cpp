#include <iostream>
#include <climits>

int main() {
    // Example array
    int arr[] = {42, 17, 89, 3, 56, -12, 78, 25};
    int n = sizeof(arr) / sizeof(arr[0]);

    // Initialize minimum with the first element
    int min = arr[0];

    // Loop through the array starting from the second element
    for (int i = 1; i < n; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }

    std::cout << "The minimum number in the array is: " << min << std::endl;

    return 0;
}